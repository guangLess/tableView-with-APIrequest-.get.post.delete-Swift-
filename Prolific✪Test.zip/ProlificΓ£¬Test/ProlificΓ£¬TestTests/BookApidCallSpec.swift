//
//  BookApidCallSpec.swift
//  Prolific✪Test
//
//  Created by Guang on 5/27/16.
//  Copyright © 2016 Guang. All rights reserved.
//
/*
import UIKit
import Quick
import Nimble

class BookApidCallSpec: QuickSpec {
    
    class BookApiCallTest: BookApidCall{
        var getBookDataCalled = false
        var bookResult: BookApiCall.bookArray
        
        override func getBookData(completion: ([[String: AnyObject]]) -> Void) {
            getBookDataCalled = true
            completion(bookResult)
        }
        
    }

}
*/