//
//  APIKeys.swift
//  Prolific✪Test
//
//  Created by Guang on 5/12/16.
//  Copyright © 2016 Guang. All rights reserved.
//

import Foundation
struct APIKey {
    let getApi = "http://prolific-interview.herokuapp.com/5720c9b20574870009d73afc/books?"
    let postApi = "http://prolific-interview.herokuapp.com/5720c9b20574870009d73afc/books"
}